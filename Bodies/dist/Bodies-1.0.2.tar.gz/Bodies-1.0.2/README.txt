Bodies　Ver1.0.0
SAGISAKA Hayato, SHIMADA Hiroshi
2015/01/16
Open Source Software
Contact; g1244497@cse.kyoto-su.ac.jp or g1244541@cse.kyoto-su.ac.jp
The reference; http://www.cc.kyoto-su.ac.jp/~atsushi/Programs/Python/DragonPrgrammingProcess/index-j.html
==========================================================================================

Copyright 2014-2015 SAGISAKA Hayato, SHIMADA Hiroshi. All rights reserved.

This program draws three-dimensional Dragon, Wasp, Penguin, Baby, Bunny, and Demon.
Procedure is as follows.
Please pull the following command in the directry where this README.txt exists.

$ make test

If you want to install Bodies, input information.

$ make install

After you input information, you open this application if you double-click the mouse button on the icon. 





